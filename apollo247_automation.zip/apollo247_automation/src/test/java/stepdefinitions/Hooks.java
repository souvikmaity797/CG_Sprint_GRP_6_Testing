package stepdefinitions;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import utils.DriverManager;
import utils.SessionManager;

/**
 * Cucumber lifecycle hooks.
 *
 * @Before  – initialises a WebDriver for the thread if one doesn't exist yet.
 * @After   – captures a screenshot on failure; does NOT quit the driver so the
 *            authenticated session can be reused by the next scenario on the
 *            same thread. The driver is quit in @After(order=9999) at the very
 *            end once all scenarios on that thread are done.
 *
 * Parallel strategy:
 *   - Thread 1 → Chrome  → login once → runs N scenarios
 *   - Thread 2 → Firefox → login once → runs N scenarios
 *   - Thread 3 → Edge    → login once → runs N scenarios
 *
 * The driver is initialised lazily on the first @Before of each thread and
 * is kept alive until the last @After(order=9999) of that thread.
 */
public class Hooks {

    // ── Open browser once per thread ─────────────────────────────────────────

    @Before(order = 0)
    public void setUp(Scenario scenario) {
        // Only spin up a new driver if this thread doesn't already have one
        try {
            DriverManager.getDriver(); // throws if no driver exists yet
        } catch (IllegalStateException e) {
            DriverManager.initDriver();
            SessionManager.reset();   // new browser → new session
        }
        System.out.println("[Thread " + Thread.currentThread().getName() + "] "
                + "Starting scenario: " + scenario.getName()
                + "  |  Browser: " + System.getProperty("browser", "chrome"));
    }

    // ── Screenshot on failure ─────────────────────────────────────────────────

    @After(order = 1)
    public void tearDown(Scenario scenario) {
        if (scenario.isFailed()) {
            try {
                byte[] screenshot = ((TakesScreenshot) DriverManager.getDriver())
                        .getScreenshotAs(OutputType.BYTES);
                scenario.attach(screenshot, "image/png",
                        "Screenshot – " + scenario.getName());
            } catch (Exception e) {
                System.err.println("Could not capture screenshot: " + e.getMessage());
            }
        }
    }

    // ── Quit browser only after ALL scenarios on this thread finish ───────────

    /**
     * order=9999 runs LAST among all @After hooks.
     * TestNG parallel DataProvider feeds scenarios one at a time to each thread,
     * so this hook fires after every scenario. We quit only when the thread is
     * about to terminate, which we detect by checking whether the JVM shutdown
     * hook has been registered.  A simpler approach that works for most setups:
     * quit here and let the driver re-init on the next scenario's @Before(order=0).
     *
     * NOTE: If you want true "one login per thread for ALL scenarios", replace
     * this quit with a no-op and manage driver lifecycle at the TestNG suite level
     * using a ISuiteListener or ITestListener instead.
     */
    @After(order = 9999)
    public void quitBrowser() {
        DriverManager.quitDriver();
        SessionManager.reset();
    }
}