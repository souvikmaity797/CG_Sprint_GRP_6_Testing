package utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

import java.time.Duration;

/**
 * Thread-safe WebDriver factory using ThreadLocal.
 *
 * Each parallel thread gets its own isolated WebDriver instance.
 * Browser is selected via the system property "browser" (default: chrome).
 *
 * Usage:
 *   DriverManager.initDriver();          // call once per scenario (Before hook)
 *   DriverManager.getDriver();           // use anywhere in the thread
 *   DriverManager.quitDriver();          // call once per scenario (After hook)
 *
 * Run with:
 *   -Dbrowser=chrome   (default)
 *   -Dbrowser=firefox
 *   -Dbrowser=edge
 */
public class DriverManager {

    private static final ThreadLocal<WebDriver> driverThread = new ThreadLocal<>();

    private DriverManager() {}

    // ── Init ─────────────────────────────────────────────────────────────────

    public static void initDriver() {
        String browser = System.getProperty("browser", "chrome").trim().toLowerCase();
        WebDriver driver;

        switch (browser) {
            case "firefox":
                FirefoxOptions ffOptions = new FirefoxOptions();
                driver = new FirefoxDriver(ffOptions);
                break;

            case "edge":
                EdgeOptions edgeOptions = new EdgeOptions();
                driver = new EdgeDriver(edgeOptions);
                break;

            case "chrome":
            default:
                ChromeOptions chromeOptions = new ChromeOptions();
                driver = new ChromeDriver(chromeOptions);
                break;
        }

        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
        driverThread.set(driver);
    }

    // ── Access ────────────────────────────────────────────────────────────────

    public static WebDriver getDriver() {
        WebDriver driver = driverThread.get();
        if (driver == null) {
            throw new IllegalStateException(
                "WebDriver not initialised for thread [" + Thread.currentThread().getName() + "]. "
                + "Call DriverManager.initDriver() in a @Before hook.");
        }
        return driver;
    }

    // ── Teardown ──────────────────────────────────────────────────────────────

    public static void quitDriver() {
        WebDriver driver = driverThread.get();
        if (driver != null) {
            driver.quit();
            driverThread.remove();
        }
    }
}
