package utils;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Utility class for reading test data from Excel (.xlsx) using Apache POI.
 *
 * Excel file: src/test/resources/testdata/testdata.xlsx
 *
 * Sheets  → rows are indexed from 0 (header = row 0, first data row = row 1).
 * Columns → addressed by header name (case-insensitive).
 */
public class ExcelUtil {

    // ── Location of the workbook relative to the project root ────────────────
    private static final String EXCEL_PATH =
            System.getProperty("user.dir") + "/src/test/resources/testdata/testdata.xlsx";

    // ── Sheet names (constants to avoid magic strings across the project) ─────
    public static final String SHEET_LOGIN   = "LoginData";
    public static final String SHEET_SEARCH  = "SearchData";
    public static final String SHEET_CART    = "CartData";
    public static final String SHEET_ADDRESS = "AddressData";
    public static final String SHEET_COUPON  = "CouponData";
    public static final String SHEET_PAYMENT = "PaymentData";

    // ─────────────────────────────────────────────────────────────────────────
    // Core helpers
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Opens the workbook and returns the requested sheet.
     * Caller is responsible for closing the workbook.
     */
    private static Sheet getSheet(Workbook wb, String sheetName) {
        Sheet sheet = wb.getSheet(sheetName);
        if (sheet == null) {
            throw new IllegalArgumentException(
                    "Sheet '" + sheetName + "' not found in " + EXCEL_PATH);
        }
        return sheet;
    }

    /**
     * Builds a column-name → column-index map from the header row (row 0).
     */
    private static Map<String, Integer> buildHeaderMap(Row headerRow) {
        Map<String, Integer> map = new HashMap<>();
        for (Cell cell : headerRow) {
            map.put(cell.getStringCellValue().trim().toLowerCase(),
                    cell.getColumnIndex());
        }
        return map;
    }

    /**
     * Returns the string value of a cell regardless of its type.
     * Numeric cells are formatted without a decimal point when the value is whole.
     */
    private static String getCellValue(Cell cell) {
        if (cell == null) return "";
        DataFormatter formatter = new DataFormatter();
        return formatter.formatCellValue(cell).trim();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Public API
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Returns the total number of data rows (excluding header) in a sheet.
     */
    public static int getRowCount(String sheetName) {
        try (FileInputStream fis = new FileInputStream(EXCEL_PATH);
             Workbook wb = new XSSFWorkbook(fis)) {
            Sheet sheet = getSheet(wb, sheetName);
            return sheet.getLastRowNum(); // header is row 0, so lastRowNum == data rows
        } catch (IOException e) {
            throw new RuntimeException("Cannot read Excel: " + EXCEL_PATH, e);
        }
    }

    /**
     * Fetches a single cell value by (sheet, rowIndex, columnHeader).
     *
     * @param sheetName   target sheet
     * @param rowIndex    1-based data row (1 = first data row after header)
     * @param columnName  header text of the column (case-insensitive)
     * @return cell value as String
     */
    public static String getData(String sheetName, int rowIndex, String columnName) {
        try (FileInputStream fis = new FileInputStream(EXCEL_PATH);
             Workbook wb = new XSSFWorkbook(fis)) {

            Sheet sheet = getSheet(wb, sheetName);
            Row header  = sheet.getRow(0);
            if (header == null) throw new RuntimeException("Header row missing in " + sheetName);

            Map<String, Integer> colMap = buildHeaderMap(header);
            Integer colIdx = colMap.get(columnName.trim().toLowerCase());
            if (colIdx == null) {
                throw new IllegalArgumentException(
                        "Column '" + columnName + "' not found in sheet '" + sheetName + "'");
            }

            Row dataRow = sheet.getRow(rowIndex); // rowIndex 1 = Excel row 2
            if (dataRow == null) return "";
            return getCellValue(dataRow.getCell(colIdx));

        } catch (IOException e) {
            throw new RuntimeException("Cannot read Excel: " + EXCEL_PATH, e);
        }
    }

    /**
     * Returns an entire data row as a Map (columnName → value).
     * rowIndex is 1-based (1 = first data row).
     */
    public static Map<String, String> getRowData(String sheetName, int rowIndex) {
        try (FileInputStream fis = new FileInputStream(EXCEL_PATH);
             Workbook wb = new XSSFWorkbook(fis)) {

            Sheet sheet  = getSheet(wb, sheetName);
            Row header   = sheet.getRow(0);
            Row dataRow  = sheet.getRow(rowIndex);

            Map<String, String> result = new HashMap<>();
            if (header == null || dataRow == null) return result;

            for (Cell hCell : header) {
                String key = hCell.getStringCellValue().trim();
                Cell   dCell = dataRow.getCell(hCell.getColumnIndex());
                result.put(key, getCellValue(dCell));
            }
            return result;

        } catch (IOException e) {
            throw new RuntimeException("Cannot read Excel: " + EXCEL_PATH, e);
        }
    }

    /**
     * Finds the first data row whose "TestCaseID" column matches the given id
     * and returns that row as a Map.
     *
     * @param sheetName  target sheet
     * @param testCaseId value to search (e.g. "TC_AP_01_01")
     * @return map of columnName → value, or empty map if not found
     */
    public static Map<String, String> getDataByTestCaseId(String sheetName, String testCaseId) {
        try (FileInputStream fis = new FileInputStream(EXCEL_PATH);
             Workbook wb = new XSSFWorkbook(fis)) {

            Sheet sheet  = getSheet(wb, sheetName);
            Row   header = sheet.getRow(0);
            if (header == null) return new HashMap<>();

            Map<String, Integer> colMap = buildHeaderMap(header);
            Integer idColIdx = colMap.get("testcaseid");
            if (idColIdx == null) throw new RuntimeException("'TestCaseID' column not found in " + sheetName);

            for (int r = 1; r <= sheet.getLastRowNum(); r++) {
                Row row = sheet.getRow(r);
                if (row == null) continue;
                if (testCaseId.equalsIgnoreCase(getCellValue(row.getCell(idColIdx)))) {
                    Map<String, String> result = new HashMap<>();
                    for (Cell hCell : header) {
                        String key   = hCell.getStringCellValue().trim();
                        Cell   dCell = row.getCell(hCell.getColumnIndex());
                        result.put(key, getCellValue(dCell));
                    }
                    return result;
                }
            }
            return new HashMap<>();

        } catch (IOException e) {
            throw new RuntimeException("Cannot read Excel: " + EXCEL_PATH, e);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Convenience typed getters (build on getData / getDataByTestCaseId)
    // ─────────────────────────────────────────────────────────────────────────

    /** Retrieves login credentials row. */
    public static Map<String, String> getLoginData() {
        return getRowData(SHEET_LOGIN, 1);
    }

    /** Retrieves search test data by TestCaseID. */
    public static Map<String, String> getSearchData(String testCaseId) {
        return getDataByTestCaseId(SHEET_SEARCH, testCaseId);
    }

    /** Retrieves cart test data by TestCaseID. */
    public static Map<String, String> getCartData(String testCaseId) {
        return getDataByTestCaseId(SHEET_CART, testCaseId);
    }

    /** Retrieves address test data by TestCaseID. */
    public static Map<String, String> getAddressData(String testCaseId) {
        return getDataByTestCaseId(SHEET_ADDRESS, testCaseId);
    }

    /** Retrieves coupon test data by TestCaseID. */
    public static Map<String, String> getCouponData(String testCaseId) {
        return getDataByTestCaseId(SHEET_COUPON, testCaseId);
    }

    /** Retrieves payment test data by TestCaseID. */
    public static Map<String, String> getPaymentData(String testCaseId) {
        return getDataByTestCaseId(SHEET_PAYMENT, testCaseId);
    }
}